$(document).ready(function(){

  alert("Hi!!");

});