from django.apps import AppConfig


class SyraappConfig(AppConfig):
    name = 'syraApp'
